# 目標理財規劃器

設定一個理財目標，用 PV（現值）、FV（終值）、PMT（每期投入）算出該怎麼存，並提供差距分析與調整建議。純靜態網站，沒有建置步驟、沒有後端。

## 專案結構

```
finance-planner/
├── public/
│   ├── index.html     # 整個網站（HTML + CSS + JS）
│   └── _headers       # Cloudflare 安全標頭
├── wrangler.jsonc     # Cloudflare Workers 靜態資源設定
├── package.json
├── .gitignore
└── README.md
```

## 本機預覽

直接用瀏覽器開啟 `public/index.html` 即可。或在專案資料夾執行：

```bash
python3 -m http.server 8000 --directory public
```

然後開啟 http://localhost:8000。

## 上傳到 GitHub

```bash
cd finance-planner
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<你的帳號>/finance-planner.git
git push -u origin main
```

（先在 GitHub 網站建立一個空的 repository，不要勾選建立 README。）

## 部署到 Cloudflare

### 方法一：Pages 連接 GitHub（最簡單）

1. Cloudflare 後台 → Workers & Pages → Create → Pages → Connect to Git
2. 選擇剛建立的 repository
3. 設定：
   - Framework preset：None
   - Build command：留空
   - Build output directory：`public`
4. 按 Save and Deploy，完成後會得到 `xxx.pages.dev` 網址。之後每次 push 到 `main` 會自動重新部署。

### 方法二：Workers 連接 GitHub

1. Workers & Pages → Create → Workers → Import a repository
2. 選擇 repository，Build command 留空，Deploy command 使用預設的 `npx wrangler deploy`
3. 專案內的 `wrangler.jsonc` 已指定靜態資源資料夾為 `public`。

### 方法三：用指令直接部署

```bash
npx wrangler login
npx wrangler deploy
```

## 自訂網域

部署完成後，在該專案的 Custom domains 綁定你的網域即可。

## 計算公式

以月複利計算，i = 年報酬率 ÷ 12，n = 年數 × 12：

- FV = PV(1+i)ⁿ + PMT × [(1+i)ⁿ − 1] ÷ i
- PMT = (FV − PV(1+i)ⁿ) × i ÷ [(1+i)ⁿ − 1]
- 目標金額會先依通膨率換算成未來的名目金額

## 免責聲明

本工具為試算與教育用途，報酬率為假設值，實際投資有波動與虧損風險，不構成投資建議。
